var update = [{
		uname:"บาบิบูเบะ",
		ulink:"http://www.janbin.com/profile/%E0%B8%9A%E0%B8%B2%E0%B8%9A%E0%B8%B4%E0%B8%9A%E0%B8%B9%E0%B9%80%E0%B8%9A%E0%B8%B0",
		uimg:"http://www.janbin.com/farm/avatar_org/1/1/avt_27_5718.jpg",
		rid:2767,
		rtitle:"Kacha Kacha",
		rlink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2767-Kacha-Kacha",
		rimg:"http://ja.files-media.com/image/1/14/img_20669_tmp_WaUgH_382x382.JPG",
		rimglink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2767-Kacha-Kacha/%E0%B9%80%E0%B8%A1%E0%B8%99%E0%B8%B9/20669",
		rdesc:"ร้านอาหารญี่ปุ่นสไตล์เทปันยากิและยากิโทริ",
		rratting:80
	},
	{
		uname:"ฮะหมูสลาตัน",
		ulink:"http://www.janbin.com/profile/%E0%B8%AE%E0%B8%B0%E0%B8%AB%E0%B8%A1%E0%B8%B9%E0%B8%AA%E0%B8%A5%E0%B8%B2%E0%B8%95%E0%B8%B1%E0%B8%99",
		uimg:"http://www.janbin.com/farm/avatar_org/1/1/avt_29_3515.jpg",
		rid:2766,
		rtitle:"ภูตะวันลูกชิ้นปลาเย็นตาโฟ (คันคลอง)",
		rlink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2766-%E0%B8%A0%E0%B8%B9%E0%B8%95%E0%B8%B0%E0%B8%A7%E0%B8%B1%E0%B8%99%E0%B8%A5%E0%B8%B9%E0%B8%81%E0%B8%8A%E0%B8%B4%E0%B9%89%E0%B8%99%E0%B8%9B%E0%B8%A5%E0%B8%B2%E0%B9%80%E0%B8%A2%E0%B9%87%E0%B8%99%E0%B8%95%E0%B8%B2%E0%B9%82%E0%B8%9F-(%E0%B8%84%E0%B8%B1%E0%B8%99%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87)",
		rimg:"http://ja.files-media.com/image/1/14/img_20659_tmp_wyFY5_382x382.JPG",
		rimglink:"http://ja.files-media.com/image/1/14/img_20659_tmp_wyFY5_382x382.JPG",
		rdesc:"ร้านก๋วยเตี๋ยวเน้นฝีมือและคุณภาพ มีเมนูเด็ดเป็น \"เย็นตาโฟฟ้าผ่า\"",
		rratting:100
	},
	{uname:"น้องไข่",
		ulink:"http://www.janbin.com/profile/%E0%B8%99%E0%B9%89%E0%B8%AD%E0%B8%87%E0%B9%84%E0%B8%82%E0%B9%88",
		uimg:"http://www.janbin.com/farm/avatar_org/1/1/avt_37_48422.jpg",
		rid:2765,
		rtitle:"Evaime Shabu Shabu สาขาสยามพารากอน",
		rlink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2765-Evaime-Shabu-Shabu-%E0%B8%AA%E0%B8%B2%E0%B8%82%E0%B8%B2%E0%B8%AA%E0%B8%A2%E0%B8%B2%E0%B8%A1%E0%B8%9E%E0%B8%B2%E0%B8%A3%E0%B8%B2%E0%B8%81%E0%B8%AD%E0%B8%99",
		rimg:"http://ja.files-media.com/image/1/14/img_20652_tmp_SdEYi_382x382.jpg",
		rimglink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2765-Evaime-Shabu-Shabu-%E0%B8%AA%E0%B8%B2%E0%B8%82%E0%B8%B2%E0%B8%AA%E0%B8%A2%E0%B8%B2%E0%B8%A1%E0%B8%9E%E0%B8%B2%E0%B8%A3%E0%B8%B2%E0%B8%81%E0%B8%AD%E0%B8%99/%E0%B9%80%E0%B8%A1%E0%B8%99%E0%B8%B9/20652",
		rdesc:"ชาบูไต้หวัน โดดเด่นที่น้ำจิ้มและเนื้อ",
		rratting:60
	},
	{uname:"crystal",
		ulink:"http://www.janbin.com/profile/crystal",
		uimg:"http://www.janbin.com/farm/avatar_org/1/1/avt_18_52477.jpg",
		rid:2131,
		rtitle:"Subway สาขาเซ็นทรัลแจ้งวัฒนะ",
		rlink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2131-Subway-%E0%B8%AA%E0%B8%B2%E0%B8%82%E0%B8%B2%E0%B9%80%E0%B8%8B%E0%B9%87%E0%B8%99%E0%B8%97%E0%B8%A3%E0%B8%B1%E0%B8%A5%E0%B9%81%E0%B8%88%E0%B9%89%E0%B8%87%E0%B8%A7%E0%B8%B1%E0%B8%92%E0%B8%99%E0%B8%B0",
		rimg:"http://ja.files-media.com/image/1/14/img_20644_tmp_MVGPc_382x382.jpg",
		rimglink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2131-Subway-%E0%B8%AA%E0%B8%B2%E0%B8%82%E0%B8%B2%E0%B9%80%E0%B8%8B%E0%B9%87%E0%B8%99%E0%B8%97%E0%B8%A3%E0%B8%B1%E0%B8%A5%E0%B9%81%E0%B8%88%E0%B9%89%E0%B8%87%E0%B8%A7%E0%B8%B1%E0%B8%92%E0%B8%99%E0%B8%B0/%E0%B9%80%E0%B8%A1%E0%B8%99%E0%B8%B9/20644",
		rdesc:"เนรมิตแซนวิสชิ้นโต ในสไตล์ของคุณเอง",
		rratting:100
	},
	{uname:"บาบิบูเบะ",
		ulink:"http://www.janbin.com/profile/%E0%B8%9A%E0%B8%B2%E0%B8%9A%E0%B8%B4%E0%B8%9A%E0%B8%B9%E0%B9%80%E0%B8%9A%E0%B8%B0",
		uimg:"http://www.janbin.com/farm/avatar_org/1/1/avt_27_5718.jpg",
		rid:2762,
		rtitle:"Cafe Camero ",
		rlink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2762-Cafe-Camero",
		rimg:"http://ja.files-media.com/image/1/14/img_20626_tmp_eDDEr_460x460.jpg",
		rimglink:"http://www.janbin.com/%E0%B8%A3%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%A7/2762-Cafe-Camero/%E0%B9%80%E0%B8%A1%E0%B8%99%E0%B8%B9/20626",
		rdesc:"กาแฟสดหอม ๆ @ พระราม 2 ปาร์ค",
		rratting:80
	}
	];

	var list = $('.list').clone();
	$('.notification').html('');
	//alert(update.length);
	for(var i=0;i<update.length;i++)
	{
		var newList = $(list).clone();
		$(newList).find('.thm-user')[0].href=update[i].ulink;
		$(newList).find('.thm-user img')[0].src=update[i].uimg;
		$(newList).find('.thm-uname')[0].href=update[i].ulink;
		$(newList).find('.thm-uname em')[0].innerHTML= '@'+update[i].uname;
		$(newList).find('.detail a')[0].href=update[i].rlink;
		$(newList).find('.detail a')[0].innerHTML=update[i].rtitle;
		$(newList).find('.detail span')[0].innerHTML = update[i].rdesc;
		$(newList).find('.review-img-link').href=update[i].rimglink;
		$(newList).find('.review-img')[0].src=update[i].rimg;
		$(newList).find('.score').css('width',update[i].rratting+'%');
		$(newList).appendTo('.notification');
	}
	$('a').click(function(){
		chrome.tabs.create({
			url :this.href,
			active :true
		})
	});
	$('.list').mouseover(function(){
			$(this).addClass('over');
	}).mouseout(function(){
		$(this).removeClass('over');
	});