/*
chrome.runtime.onInstalled.addListener(function(){
	this.db = openDatabase('notification', '1.0', 'janbin notification', 8192);
	this.db.transaction(function(tx) {
	  tx.executeSql("create table if not exists " +
		"notification(id integer primary key asc, time integer, user_id string," +
				  "user_name string, user_image string,review_title string,review_link string, review_desc string,review_img string,review_ratting float",
		[],
		function() { console.log("siucc"); }
	  );
	});
});
*/
chrome.browserAction.setBadgeText({
    text: "5"
});

if (window.webkitNotifications) {
	if (window.webkitNotifications.checkPermission() == 1) { // 0 is PERMISSION_ALLOWED
		window.webkitNotifications.requestPermission();
  } 
	//window.webkitNotifications.createNotification('icon.png', 'Notification Title', 'Notification content...').show();
	//window.webkitNotifications.createHTMLNotification('notification.html').show();
}
function notificationOndisplay(){
}
function notificationOnclose(){
}
function notificationShow(){
}
//chrome.tts.speak('Hello Welcome to e,d,t guide dot com.');

chrome.topSites.get(function(r){
	//alert(r[0].url);
});
chrome.pushMessaging.getChannelId(true,function(ch){
	console.log(ch);
	console.log(ch.channelId);
});
chrome.pushMessaging.onMessage.addListener(function(msg){
	//window.webkitNotifications.createNotification('images/icon48.png','PushNotification','Have a message').show();
	//chrome.tts.speak('Hello Have a message to you', {'enqueue': true});
	console.log(msg);
});

